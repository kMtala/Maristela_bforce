<?php
$host = 'localhost';
$db = 'tala';
$user = 'root';
$pass = '';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define the password
$password = 'password'; // Example password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// SQL query to insert a new user into the 'users' table
$sql = "INSERT INTO users (username, password) VALUES ('talaa', '$hashed_password')";

// Execute the SQL query
if ($conn->query($sql) === TRUE) {
    echo "New user added successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
