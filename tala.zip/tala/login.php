<?php
session_start();
$host = 'localhost';
$db = 'tala';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getUser($conn, $username) {
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $stmt->close();
        return null;
    }
    $stmt->bind_result($stored_password);
    $stmt->fetch();
    $stmt->close();
    return $stored_password; // Now we return the plain password stored in the DB
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the user is locked out
    $stmt = $conn->prepare("SELECT attempts, locked_until FROM login_attempts WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($attempts, $locked_until);
    $stmt->fetch();
    $stmt->close();

    $current_time = time();

    // If locked out, check lock duration
    if ($attempts >= 5 && strtotime($locked_until) > $current_time) {
        echo "<div class='message'>You are locked out. Try again after 5 minutes.</div>";
    } else {
        // Reset if lock duration has passed or no attempts found
        if ($attempts >= 5 && strtotime($locked_until) <= $current_time) {
            $attempts = 0;
            $locked_until = null;
        }

        // Get the stored password from the database (plain text now)
        $stored_password = getUser($conn, $username);

        // Check if the password is correct
        if ($stored_password && $password === $stored_password) {
            echo "Welcome, $username!";
            // Reset the attempts on successful login
            $stmt = $conn->prepare("DELETE FROM login_attempts WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->close();
        } else {
            // If login fails, increment the attempt count
            $attempts++;
            $lock_time = ($attempts >= 5) ? date('Y-m-d H:i:s', $current_time + 300) : null;

            // Insert or update login attempts
            $stmt = $conn->prepare("INSERT INTO login_attempts (username, attempts, last_attempt, locked_until)
                VALUES (?, ?, NOW(), ?)
                ON DUPLICATE KEY UPDATE attempts = ?, last_attempt = NOW(), locked_until = ?");
            $stmt->bind_param("sisss", $username, $attempts, $lock_time, $attempts, $lock_time);
            $stmt->execute();
            $stmt->close();

            echo "<div class='message'>Invalid username or password. Attempt: $attempts</div>";
        }
    }
}

$conn->close();
?>
